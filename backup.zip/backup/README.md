# Dasher
A small side-scrolling hack and slash game -- WIP

# C++
=====================================================

This project uses STB for some actions
STB is a free to use (Public Domain) Library
https://github.com/nothings/stb

For testing i've used the following graphics

SimonSpriteSheet.png - Venkman
https://opengameart.org/content/simon-the-secret-agent

grass.png - The Chayed
https://opengameart.org/content/hand-painted-grass-texture
